#' Circular OT Distance between two samples
#'
#' Computes the circular OT distance between two data samples supported on the circle.
#'
#' @param sample1 numerical vector of sample
#' @param sample2 numerical vector of sample
#' @param typeOfData either "UnitInt", "Radian", or "Angles". "UnitInt": Data lies on the unit interval [0,1), "Radian": Data is parametrized in radians [0,2*pi), "Angles": Data is given by angles [0°,360°).
#'
#' @return COT distance between sample1 and sample2.
#'
#' @examples
#' cot.dist_Samples(c(0.2,0.5,0.8),c(0.4,0.5,0.7), "UnitInt") # = 1/10
#' cot.dist_Samples(c(pi,pi/2),c(pi/4), "Radian")             # = 1/4
#' cot.dist_Samples(c(0,90,270),c(180), "Angles")             # = 1/3
#'
#' @export

cot.dist_Samples <- function(sample1, sample2, typeOfData="UnitInt"){

  if(is.character(typeOfData)==FALSE){
    stop("Type of Data has to be specified as \"UnitInt\", \"Radian\" or \"Angles\".")
    return()
  }
  if(typeOfData=="UnitInt"){
    sample1 = (sample1 %% 1)
    sample2 = (sample2 %% 1)
  }
  else if(typeOfData=="Radian"){
    sample1 = (sample1 %% (2*pi))/(2*pi)
    sample2 = (sample2 %% (2*pi))/(2*pi)
  }
  else if(typeOfData=="Angles"){
    sample1 = (sample1 %% 360)/360
    sample2 = (sample2 %% 360)/360
  }
  else{
    stop("Type of Data has to be specified as \"UnitInt\", \"Radian\" or \"Angles\".")
  }

  orderOfSamples = order(c(sample1,sample2))

  combinedSample = c(c(sample1,sample2)[orderOfSamples],1)
  k = length(combinedSample)-1

  diffCDFs = cumsum(c(rep(1/length(sample1),length(sample1)), rep(-1/length(sample2),length(sample2)))[orderOfSamples])
  order_diffCDFs = order(diffCDFs)
  sorted_diffCDFs = diffCDFs[order_diffCDFs]

  weighting = combinedSample[2:(k+1)] - combinedSample[1:k]
  levMed = sorted_diffCDFs[which(cumsum(weighting[order_diffCDFs])>=0.5)[1]]

  return(sum(abs(diffCDFs - levMed)*weighting))
}
