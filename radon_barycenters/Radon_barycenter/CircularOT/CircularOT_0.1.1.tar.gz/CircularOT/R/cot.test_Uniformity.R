#' Circular OT Test (COTT) for uniformity
#'
#' COTT testing for uniform distribution.
#'
#' @param sample numerical vector of sample.
#' @param D order of discretization.
#' @param typeOfData either "UnitInt", "Radian", or "Angles". "UnitInt": Data lies on the unit interval [0,1), "Radian": Data is parametrized in radians [0,2*pi), "Angles": Data is given by angles [0°,360°).
#'
#' @return Test Statistic and p-value of test result of COTT for uniformity.
#'
#' @examples
#' set.seed(0)
#' cot.test_Uniformity(runif(100), typeOfData = "UnitInt")        # P-Value: 0.3666
#' cot.test_Uniformity(seq(pi/2,pi, 0.5), typeOfData = "Radian")  # P-Value: 0.0714
#' cot.test_Uniformity(seq(0,210,30), typeOfData = "Angles")      # P-Value: 0.3421
#'
#' @export

cot.test_Uniformity <- function(sample, D = 1000, typeOfData="UnitInt"){
  if(is.character(typeOfData)==FALSE){
    stop("Type of Data has to be specified as \"UnitInt\", \"Radian\" or \"Angles\".")
    return()
  }
  if(typeOfData=="UnitInt"){
    sample = (sample %% 1)
  }
  else if(typeOfData=="Radian"){
    sample = (sample %% (2*pi))/(2*pi)
  }
  else if(typeOfData=="Angles"){
    sample = (sample %% 360)/360
  }
  else{
    stop("Type of Data has to be specified as \"UnitInt\", \"Radian\" or \"Angles\".")
  }

  cat("\n         One-Sample COTT for Uniformity\n")
  testStatistic  = sqrt(length(sample))*cot.dist_Samples(sample, seq(0,1-1/D,1/D), "UnitInt")
  cat("Test statistic: ", testStatistic, "\n")
  if(testStatistic>10){
    pvalue = 0
  }
  else{
    limitCDF = stats::approxfun(seq(0,10,10^(-4)),utils::read.csv(system.file("LimitLawCDFs","LimitLawCDFUniform.csv", package ="CircularOT"))$CDF)
    pvalue = base::round(1-limitCDF(testStatistic), 4)
    cat("P-Value:        ", pvalue, "\n\n")
  }
}
