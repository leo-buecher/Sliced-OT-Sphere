#' Circular OT Distance between a sample and a von Mises distributions
#'
#' Computes the circular OT distance between a sample and a von Mises distribution with specified parameters.
#'
#' @param sample numerical vector of sample.
#' @param mu mean of the von Mises distribution.
#' @param kappa concentration parameter of von Mises distribution, parameter must be non-negative.
#' @param D order of discretization.
#' @param typeOfData either "UnitInt", "Radian", or "Angles". "UnitInt": Data lies on the unit interval [0,1), "Radian": Data is parametrized in radians [0,2*pi), "Angles": Data is given by angles [0°,360°).
#'
#' @return COT distance between sample and von Mises distribution with specified parameters.
#'
#' @examples
#' ###cot.dist_Sample_Uniform(c(0,0.5), D = 1000, typeOfData="UnitInt")        # = 0.125
#' ###cot.dist_Sample_Uniform(c(pi/2,3*pi/2), D = 1000, typeOfData="Radian")   # = 0.125
#' ###cot.dist_Sample_Uniform(c(0,90,180,270), D = 10000, typeOfData="Angles") # = 0.0625
#'
#' @export


cot.dist_Sample_VonMises<- function(sample, mu = 0, kappa = 1, D = 1000, typeOfData="UnitInt"){

  if(is.character(typeOfData)==FALSE){
    stop("Type of Data has to be specified as \"UnitInt\", \"Radian\" or \"Angles\".")
    return()
  }
  if(typeOfData=="UnitInt"){
    sample = (sample %% 1)
    mu = (mu %% 1)
  }
  else if(typeOfData=="Radian"){
    sample = (sample %% (2*pi))/(2*pi)
    mu = (mu %% (2*pi))/(2*pi)
  }
  else if(typeOfData=="Angles"){
    sample = (sample %% 360)/360
    mu = (mu %% (360))/(360)
  }
  else{
    stop("Type of Data has to be specified as \"UnitInt\", \"Radian\" or \"Angles\".")
  }

  return(base::round(cot.dist_Samples( (sample - mu) %% 1,
                                           as.numeric(
                                             circular::qvonmises(seq(0,1-1/D,1/D),
                                                                 circular::circular(0),
                                                                 kappa = kappa)/(2*pi) ) %% 1),
               log10(D) ) )

}
