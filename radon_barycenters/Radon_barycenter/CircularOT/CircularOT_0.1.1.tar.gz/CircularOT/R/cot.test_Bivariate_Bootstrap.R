#' Bootstrap Circular OT Test (COTT) for Goodness of Fit
#'
#' m-out-of-n bootstrap based circular OT test for goodness of fit between samples.
#'
#' @param sample1 numerical vector of sample.
#' @param sample2 numerical vector of sample.
#' @param m number of bootstrap sample size.
#' @param R number of bootstrap repititions.
#' @param D order of discretization.
#' @param typeOfData either "UnitInt", "Radian", or "Angles". "UnitInt": Data lies on the unit interval [0,1), "Radian": Data is parametrized in radians [0,2*pi), "Angles": Data is given by angles [0°,360°).
#'
#' @return Test statistic and p-value of bootstrap based bivariate COTT.
#'
#' @examples
#' set.seed(10)
#' cot.test_Bivariate_Bootstrap(runif(50),runif(50), typeOfData = "UnitInt")
#' # P-Value: 0.32
#' cot.test_Bivariate_Bootstrap(seq(1,30,1)%% (2*pi), seq(1,50,2)%% (2*pi), typeOfData = "Radian")
#' # P-Value: 0.197
#' cot.test_Bivariate_Bootstrap(seq(0,350,10), seq(50,300,10), typeOfData = "Angles")
#' # P-Value: 0.003
#'
#' @export

cot.test_Bivariate_Bootstrap <- function(sample1, sample2, m = base::ceiling(length(sample1))^0.8, R = 10000,  D = 1000, typeOfData="UnitInt"){
  if(is.character(typeOfData)==FALSE){
    stop("Type of Data has to be specified as \"UnitInt\", \"Radian\" or \"Angles\".")
    return()
  }
  if(typeOfData=="UnitInt"){
    sample1 = (sample1 %% 1)
    sample2 = (sample2 %% 1)
  }
  else if(typeOfData=="Radian"){
    sample1 = (sample1 %% (2*pi))/(2*pi)
    sample2 = (sample2 %% 1)
  }
  else if(typeOfData=="Angles"){
    sample1 = (sample1 %% 360)/360
    sample2 = (sample2 %% 360)/360
  }
  else{
    stop("Type of Data has to be specified as \"UnitInt\", \"Radian\" or \"Angles\".")
  }

  cat("\n         Bivariate (Bootstrap) COTT for Goodness of Fit\n")
  testStatistic  = sqrt(length(sample1))*cot.dist_Samples(sample1, sample2, "UnitInt")
  cat("Test statistic: ", testStatistic, "\n")

  bootstrap_TestStatistic = rep(0, R)
  for(i in 1:R){
    sample2.bs = base::sample(sample2,m, replace=TRUE)
    bootstrap_TestStatistic[i] = sqrt(m)*cot.dist_Samples(sample2, sample2.bs, "UnitInt")
  }

  bootstrap_ecdf = stats::ecdf(bootstrap_TestStatistic)
  pvalue = 1- bootstrap_ecdf(testStatistic)
  cat("P-Value:        ", pvalue, "\n\n")
}
