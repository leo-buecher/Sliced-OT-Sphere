#' Circular OT Distance between a sample and the uniform distribution
#'
#' Compute the circular OT distance between a sample and the uniform distribution on the circle.
#'
#' @param sample numerical vector of sample on [0,1).
#' @param D order of discretization.
#' @param typeOfData either "UnitInt", "Radian", or "Angles". "UnitInt": Data lies on the unit interval [0,1), "Radian": Data is parametrized in radians [0,2*pi), "Angles": Data is given by angles [0°,360°).
#'
#' @return COT distance between sample and uniform distribution.
#'
#' @examples
#' cot.dist_Sample_Uniform(c(0,0.5), D = 1000, typeOfData="UnitInt")        # = 0.125
#' cot.dist_Sample_Uniform(c(pi/2,3*pi/2), D = 1000, typeOfData="Radian")   # = 0.125
#' cot.dist_Sample_Uniform(c(0,90,180,270), D = 10000, typeOfData="Angles") # = 0.0625
#'
#' @export



cot.dist_Sample_Uniform<- function(sample, D = 1000, typeOfData="UnitInt"){
  if(is.character(typeOfData)==FALSE){
    stop("Type of Data has to be specified as \"UnitInt\", \"Radian\" or \"Angles\".")
    return()
  }
  if(typeOfData=="UnitInt"){
    sample = (sample %% 1)
  }
  else if(typeOfData=="Radian"){
    sample = (sample %% (2*pi))/(2*pi)
  }
  else if(typeOfData=="Angles"){
    sample = (sample %% 360)/360
  }
  else{
    stop("Type of Data has to be specified as \"UnitInt\", \"Radian\" or \"Angles\".")
  }

  return(round(cot.dist_Samples(sample, seq(0,1-1/D,1/D), typeOfData = "UnitInt"), log10(D) ))
}
